import numpy as np
import wave

sample_rate = 24000
duration = 245.0
n_samples = int(sample_rate * duration)
t = np.linspace(0, duration, n_samples, endpoint=False)

chords = [
    [261.63, 329.63, 392.00, 493.88], # Cmaj7
    [220.00, 261.63, 329.63, 392.00], # Am7
    [174.61, 220.00, 261.63, 329.63], # Fmaj7
    [196.00, 261.63, 293.66, 392.00]  # Gsus4
]

chord_len = 8.0
chord_indices = ((t // chord_len) % len(chords)).astype(int)

audio = np.zeros(n_samples)
for c_idx, notes in enumerate(chords):
    mask = (chord_indices == c_idx)
    if not np.any(mask):
        continue
    sub_t = t[mask]
    chord_audio = np.zeros_like(sub_t)
    for freq in notes:
        chord_audio += 0.04 * np.sin(2 * np.pi * freq * sub_t)
        chord_audio += 0.015 * np.sin(2 * np.pi * freq * 2 * sub_t)
        chord_audio += 0.008 * np.sin(2 * np.pi * freq * 0.5 * sub_t)
    audio[mask] = chord_audio

tremolo = 0.85 + 0.15 * np.sin(2 * np.pi * 0.25 * t)
audio *= tremolo

fade_len = int(sample_rate * 3.0)
fade_in = np.linspace(0, 1, fade_len)
fade_out = np.linspace(1, 0, fade_len)
audio[:fade_len] *= fade_in
audio[-fade_len:] *= fade_out

max_val = np.max(np.abs(audio))
if max_val > 0:
    audio = (audio / max_val) * 0.06 # gentle -24dB background bed

int16_audio = (audio * 32767).astype(np.int16)

out_path = "scratch/demo_video/ambient_bed.wav"
with wave.open(out_path, "w") as wav_file:
    wav_file.setnchannels(1)
    wav_file.setsampwidth(2)
    wav_file.setframerate(sample_rate)
    wav_file.writeframes(int16_audio.tobytes())

print("Vectorized ambient_bed.wav written successfully!")
