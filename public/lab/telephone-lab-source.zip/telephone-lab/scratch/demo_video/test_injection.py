import time
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

INJECTION_JS = """
(() => {
  if (document.getElementById('demo-cursor')) return;
  
  // Custom Cursor
  const cursor = document.createElement('div');
  cursor.id = 'demo-cursor';
  cursor.innerHTML = `
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" style="filter: drop-shadow(0 3px 6px rgba(0,0,0,0.45));">
      <path d="M4 3L11 20L14 13L21 10L4 3Z" fill="#0d9488" stroke="#ffffff" stroke-width="2.5" stroke-linejoin="round"/>
    </svg>
  `;
  cursor.style.cssText = `
    position: fixed;
    top: 0; left: 0;
    pointer-events: none;
    z-index: 2147483647;
    transition: transform 0.25s cubic-bezier(0.2, 0.8, 0.2, 1);
    transform: translate(-100px, -100px);
  `;
  document.body.appendChild(cursor);

  // Ripple
  const ripple = document.createElement('div');
  ripple.id = 'demo-ripple';
  ripple.style.cssText = `
    position: fixed;
    top: 0; left: 0;
    width: 48px; height: 48px;
    margin-left: -24px; margin-top: -24px;
    border-radius: 50%;
    border: 3px solid #0d9488;
    background: rgba(13, 148, 136, 0.3);
    pointer-events: none;
    z-index: 2147483646;
    opacity: 0;
    transform: scale(0.2);
    transition: transform 0.4s ease-out, opacity 0.4s ease-out;
  `;
  document.body.appendChild(ripple);

  // Spotlight box
  const spotlight = document.createElement('div');
  spotlight.id = 'demo-spotlight';
  spotlight.style.cssText = `
    position: absolute;
    pointer-events: none;
    z-index: 2147483640;
    border: 3px solid #0d9488;
    background: rgba(13, 148, 136, 0.08);
    border-radius: 12px;
    box-shadow: 0 0 25px rgba(13, 148, 136, 0.5);
    opacity: 0;
    transition: all 0.35s ease-in-out;
  `;
  document.body.appendChild(spotlight);

  // Floating Presentation Overlay (Bottom Glass Bar)
  const overlay = document.createElement('div');
  overlay.id = 'demo-overlay';
  overlay.innerHTML = `
    <div style="display: flex; align-items: center; gap: 18px;">
      <div style="width: 46px; height: 46px; border-radius: 12px; background: linear-gradient(135deg, #0d9488, #0f766e); display: flex; align-items: center; justify-content: center; font-size: 24px; color: white; font-weight: bold; box-shadow: 0 4px 12px rgba(13, 148, 136, 0.4);">↝</div>
      <div>
        <div style="font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; color: #5eead4;">Culture Coded Track · Sarvam AI Hackathon</div>
        <div id="demo-title" style="font-size: 19px; font-weight: 700; color: #ffffff; margin-top: 2px;">Viksit Garg · Introduction & The Telephone Drift Problem</div>
      </div>
    </div>
    <div style="display: flex; gap: 10px; align-items: center;">
      <span style="background: rgba(13, 148, 136, 0.25); border: 1px solid rgba(13, 148, 136, 0.6); color: #5eead4; padding: 6px 14px; border-radius: 8px; font-size: 12px; font-weight: 700; letter-spacing: 0.5px;">Sarvam-105B</span>
      <span style="background: rgba(99, 102, 241, 0.25); border: 1px solid rgba(99, 102, 241, 0.6); color: #c7d2fe; padding: 6px 14px; border-radius: 8px; font-size: 12px; font-weight: 700; letter-spacing: 0.5px;">Gemma-4 Judge</span>
      <span style="background: rgba(245, 158, 11, 0.25); border: 1px solid rgba(245, 158, 11, 0.6); color: #fde68a; padding: 6px 14px; border-radius: 8px; font-size: 12px; font-weight: 700; letter-spacing: 0.5px;">D1 Atomic Quota</span>
    </div>
  `;
  overlay.style.cssText = `
    position: fixed;
    bottom: 24px; left: 32px; right: 32px;
    background: rgba(15, 23, 42, 0.92);
    backdrop-filter: blur(16px);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 18px;
    padding: 16px 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    z-index: 2147483645;
    box-shadow: 0 20px 45px rgba(0, 0, 0, 0.5);
    font-family: system-ui, -apple-system, sans-serif;
  `;
  document.body.appendChild(overlay);

  window.setDemoTitle = (text) => {
    const el = document.getElementById('demo-title');
    if (el) el.innerText = text;
  };

  window.moveCursorTo = (x, y) => {
    cursor.style.transform = `translate(${x}px, ${y}px)`;
  };

  window.clickCursorAt = (x, y) => {
    cursor.style.transform = `translate(${x}px, ${y}px) scale(0.85)`;
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;
    ripple.style.opacity = '1';
    ripple.style.transform = 'scale(1.5)';
    setTimeout(() => {
      cursor.style.transform = `translate(${x}px, ${y}px) scale(1)`;
      ripple.style.opacity = '0';
      ripple.style.transform = 'scale(2.2)';
    }, 280);
  };

  window.highlightElement = (sel) => {
    const el = document.querySelector(sel);
    if (!el) return;
    const rect = el.getBoundingClientRect();
    spotlight.style.top = `${rect.top + window.scrollY - 6}px`;
    spotlight.style.left = `${rect.left + window.scrollX - 6}px`;
    spotlight.style.width = `${rect.width + 12}px`;
    spotlight.style.height = `${rect.height + 12}px`;
    spotlight.style.opacity = '1';
  };

  window.clearHighlight = () => {
    spotlight.style.opacity = '0';
  };
})();
"""

print("INJECTION_JS defined successfully")
