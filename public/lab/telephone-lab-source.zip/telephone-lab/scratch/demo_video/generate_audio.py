import asyncio
import edge_tts
import json
import subprocess
from pathlib import Path

VOICE = "en-IN-PrabhatNeural"
OUTPUT_DIR = Path("scratch/demo_video/audio")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

SCRIPTS = {
    "scene1_intro": "Hi, Viksit Garg this side! Today I'm presenting Telephone Lab for the Culture Coded track powered by Sarvam AI. Across India's rich linguistic landscape, conveying critical messages—such as emergency alerts, flood advisories, or civic drills—is vital. But traditional translation engines optimize for superficial fluency, not factual survival. When a message hops across languages, crucial deadlines shift, quantities change, and negative instructions like 'do not use the bridge' get dangerously dropped. We call this the Telephone drift problem.",
    
    "scene2_extraction": "Our solution is Telephone Lab: an inspectable message preservation studio and research platform. Rather than blindly translating, Telephone Lab anchors every translation to user-verified source facts. Here in the live studio, we enter an emergency drill instruction. Notice: it contains an evacuation deadline, per-person water rations, a helpline phone number, and a critical negated action. We click 'Analyze message'. Behind the scenes, Sarvam 105B extracts every atomic fact, strictly grounded with exact verbatim quotations from the original script.",
    
    "scene3_translation": "Next, the user reviews and confirms these intended facts. We can mark details critical, edit values, or add constraints. We select our target languages—here, Tamil and Telugu. Clicking 'Translate and verify' kicks off a multi-stage verification pipeline. Sarvam 105B translates the message anchored to approved facts. Then, in an independent prompt, it back-translates the native script into English without seeing the source facts. Next, every approved fact is checked against observed evidence, backed by deterministic guards for dates, times, and Indian number grouping.",
    
    "scene4_repair_judge": "Now look at Telugu. In the initial translation, the deadline nuance shifted from 'by 6 PM' to 'before 6 PM'. Our automated audit instantly caught this condition alteration and triggered an automatic bounded repair. Because the nuance remained slightly ambiguous, Telephone Lab refused to fabricate a false passing score, transparently marking it 'needs review'. Even better, to prevent single-model circular bias, we integrated a completely independent AI model family: Gemma-4 via Sarvam's V2 API. Gemma acts as an impartial judge, evaluating translation preservation and explicitly tracking agreements and disagreements side-by-side.",
    
    "scene5_research_evidence": "Beyond the live studio, Telephone Lab features a research laboratory at slash lab, simulating multi-hop telephone chains across languages—like Hindi to Tamil to Hindi—measuring Critical Fact Survival and danger rates across successive retellings. And under slash evidence, we maintain a live multi-language coverage matrix across ten Indian languages, D1 atomic spend caps, fail-closed token quotas, and cryptographic native-speaker review packs for gold-standard calibration.",
    
    "scene6_conclusion": "Under the hood, Telephone Lab is built with React 19, TypeScript, Tailwind CSS, Cloudflare Workers with D1 SQLite, FastAPI, and Sarvam AI's 105B and Gemma models, verified by one hundred automated test cases. Telephone Lab brings trust, transparency, and grounded fact preservation to Indian language AI. Thank you!"
}

async def generate():
    durations = {}
    for name, text in SCRIPTS.items():
        out_file = OUTPUT_DIR / f"{name}.mp3"
        communicate = edge_tts.Communicate(text, VOICE, rate="+3%")
        await communicate.save(str(out_file))
        
        # Get duration
        cmd = ["ffprobe", "-i", str(out_file), "-show_entries", "format=duration", "-v", "quiet", "-of", "csv=p=0"]
        dur = float(subprocess.check_output(cmd).decode().strip())
        durations[name] = dur
        print(f"Generated {name}: {dur:.2f}s")
    
    with open(OUTPUT_DIR / "durations.json", "w") as f:
        json.dump(durations, f, indent=2)
    print("Total audio duration:", sum(durations.values()), "seconds")

if __name__ == "__main__":
    asyncio.run(generate())
