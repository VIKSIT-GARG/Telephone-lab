import time
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

BASE_URL = "http://127.0.0.1:8787"
VIDEO_DIR = Path("scratch/demo_video/raw_video")
VIDEO_DIR.mkdir(parents=True, exist_ok=True)

with open("scratch/demo_video/audio/durations.json") as f:
    DURATIONS = json.load(f)

INJECTION_CSS_JS = """
(() => {
  if (document.getElementById('demo-cursor')) return;
  
  // Custom Cursor
  const cursor = document.createElement('div');
  cursor.id = 'demo-cursor';
  cursor.innerHTML = `
    <svg width="34" height="34" viewBox="0 0 24 24" fill="none" style="filter: drop-shadow(0 3px 6px rgba(0,0,0,0.5));">
      <path d="M4 3L11 20L14 13L21 10L4 3Z" fill="#0d9488" stroke="#ffffff" stroke-width="2.5" stroke-linejoin="round"/>
    </svg>
  `;
  cursor.style.cssText = `
    position: fixed;
    top: 0; left: 0;
    pointer-events: none;
    z-index: 2147483647;
    transition: transform 0.2s cubic-bezier(0.2, 0.8, 0.2, 1);
    transform: translate(-100px, -100px);
  `;
  document.body.appendChild(cursor);

  // Ripple
  const ripple = document.createElement('div');
  ripple.id = 'demo-ripple';
  ripple.style.cssText = `
    position: fixed;
    top: 0; left: 0;
    width: 50px; height: 50px;
    margin-left: -25px; margin-top: -25px;
    border-radius: 50%;
    border: 3px solid #0d9488;
    background: rgba(13, 148, 136, 0.35);
    pointer-events: none;
    z-index: 2147483646;
    opacity: 0;
    transform: scale(0.2);
    transition: transform 0.4s ease-out, opacity 0.4s ease-out;
  `;
  document.body.appendChild(ripple);

  // Spotlight box
  const spotlight = document.createElement('div');
  spotlight.id = 'demo-spotlight';
  spotlight.style.cssText = `
    position: absolute;
    pointer-events: none;
    z-index: 2147483640;
    border: 3px solid #0d9488;
    background: rgba(13, 148, 136, 0.08);
    border-radius: 12px;
    box-shadow: 0 0 25px rgba(13, 148, 136, 0.5);
    opacity: 0;
    transition: all 0.35s ease-in-out;
  `;
  document.body.appendChild(spotlight);

  // Floating Presentation Overlay (Bottom Glass Bar)
  const overlay = document.createElement('div');
  overlay.id = 'demo-overlay';
  overlay.innerHTML = `
    <div style="display: flex; align-items: center; gap: 18px;">
      <div style="width: 48px; height: 48px; border-radius: 14px; background: linear-gradient(135deg, #0d9488, #0f766e); display: flex; align-items: center; justify-content: center; font-size: 26px; color: white; font-weight: bold; box-shadow: 0 4px 14px rgba(13, 148, 136, 0.4);">↝</div>
      <div>
        <div style="font-size: 13px; font-weight: 800; text-transform: uppercase; letter-spacing: 1.5px; color: #5eead4;">Culture Coded Track · Sarvam AI Hackathon</div>
        <div id="demo-title" style="font-size: 20px; font-weight: 700; color: #ffffff; margin-top: 2px;">Viksit Garg · Introduction & The Telephone Drift Problem</div>
      </div>
    </div>
    <div style="display: flex; gap: 10px; align-items: center;">
      <span style="background: rgba(13, 148, 136, 0.25); border: 1px solid rgba(13, 148, 136, 0.6); color: #5eead4; padding: 7px 15px; border-radius: 9px; font-size: 13px; font-weight: 700; letter-spacing: 0.5px;">Sarvam-105B</span>
      <span style="background: rgba(99, 102, 241, 0.25); border: 1px solid rgba(99, 102, 241, 0.6); color: #c7d2fe; padding: 7px 15px; border-radius: 9px; font-size: 13px; font-weight: 700; letter-spacing: 0.5px;">Gemma-4 Judge</span>
      <span style="background: rgba(245, 158, 11, 0.25); border: 1px solid rgba(245, 158, 11, 0.6); color: #fde68a; padding: 7px 15px; border-radius: 9px; font-size: 13px; font-weight: 700; letter-spacing: 0.5px;">D1 Atomic Quota</span>
    </div>
  `;
  overlay.style.cssText = `
    position: fixed;
    bottom: 24px; left: 32px; right: 32px;
    background: rgba(15, 23, 42, 0.94);
    backdrop-filter: blur(16px);
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 20px;
    padding: 16px 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    z-index: 2147483645;
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.55);
    font-family: system-ui, -apple-system, sans-serif;
  `;
  document.body.appendChild(overlay);

  window.setDemoTitle = (text) => {
    const el = document.getElementById('demo-title');
    if (el) el.innerText = text;
  };

  window.moveCursorTo = (x, y) => {
    cursor.style.transform = `translate(${x}px, ${y}px)`;
  };

  window.clickCursorAt = (x, y) => {
    cursor.style.transform = `translate(${x}px, ${y}px) scale(0.85)`;
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;
    ripple.style.opacity = '1';
    ripple.style.transform = 'scale(1.5)';
    setTimeout(() => {
      cursor.style.transform = `translate(${x}px, ${y}px) scale(1)`;
      ripple.style.opacity = '0';
      ripple.style.transform = 'scale(2.2)';
    }, 280);
  };

  window.highlightElement = (sel) => {
    const el = document.querySelector(sel);
    if (!el) return;
    const rect = el.getBoundingClientRect();
    spotlight.style.top = `${rect.top + window.scrollY - 6}px`;
    spotlight.style.left = `${rect.left + window.scrollX - 6}px`;
    spotlight.style.width = `${rect.width + 12}px`;
    spotlight.style.height = `${rect.height + 12}px`;
    spotlight.style.opacity = '1';
  };

  window.clearHighlight = () => {
    spotlight.style.opacity = '0';
  };
})();
"""

def smooth_move(page, start_x, start_y, end_x, end_y, duration=0.8, steps=20):
    for i in range(1, steps + 1):
        t = i / steps
        ease = 2 * t * t if t < 0.5 else -1 + (4 - 2 * t) * t
        cur_x = start_x + (end_x - start_x) * ease
        cur_y = start_y + (end_y - start_y) * ease
        page.evaluate(f"window.moveCursorTo({cur_x}, {cur_y})")
        time.sleep(duration / steps)
    return end_x, end_y

def click_element(page, x, y):
    page.evaluate(f"window.clickCursorAt({x}, {y})")
    time.sleep(0.35)

def run():
    print("Starting Playwright demo recording...")
    with sync_playwright() as p:
        browser = p.chromium.launch(
            executable_path='/usr/bin/chromium',
            headless=True,
            args=['--no-sandbox', '--disable-gpu', '--window-size=1920,1080']
        )
        context = browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            record_video_dir=str(VIDEO_DIR),
            record_video_size={'width': 1920, 'height': 1080}
        )
        page = context.new_page()
        
        # Open Studio
        page.goto(BASE_URL)
        page.wait_for_load_state("networkidle")
        page.evaluate(INJECTION_CSS_JS)
        
        cur_x, cur_y = 960, 400
        page.evaluate(f"window.moveCursorTo({cur_x}, {cur_y})")
        
        # ----------------------------------------------------
        # SCENE 1: Introduction & The Drift Problem (41.6s)
        # ----------------------------------------------------
        t0 = time.time()
        print("Scene 1 starting...")
        page.evaluate("window.setDemoTitle('1/6: Idea & The Telephone Drift Problem | Speaker: Viksit Garg')")
        
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 250, 45, duration=1.2) # Header logo
        page.evaluate("window.highlightElement('.site-header .wordmark')")
        time.sleep(3.5)
        
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 450, 200, duration=1.2) # Hero title
        page.evaluate("window.highlightElement('.intro h1')")
        time.sleep(4.5)
        
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 1400, 200, duration=1.5) # Script line
        page.evaluate("window.highlightElement('.script-line')")
        time.sleep(5.0)
        
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 1600, 310, duration=1.2) # Connection status
        page.evaluate("window.highlightElement('.connection')")
        time.sleep(4.0)
        
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 400, 315, duration=1.5) # Steps
        page.evaluate("window.highlightElement('.steps')")
        time.sleep(4.5)
        
        page.evaluate("window.clearHighlight()")
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 500, 520, duration=1.2) # Textarea
        
        # Fill remaining time for Scene 1
        rem = DURATIONS["scene1_intro"] - (time.time() - t0)
        if rem > 0:
            time.sleep(rem)
            
        # ----------------------------------------------------
        # SCENE 2: Grounded Fact Extraction (43.1s)
        # ----------------------------------------------------
        t0 = time.time()
        print("Scene 2 starting...")
        page.evaluate("window.setDemoTitle('2/6: Grounded Fact Extraction with Sarvam 105B')")
        
        # Click textarea
        click_element(page, cur_x, cur_y)
        page.focus("#message")
        
        # Type the message
        test_message = "Fictional drill: Evacuate the village by 6 PM on 17 August 2030. Bring 2 bottles of water per person. Call 98765 43210 for transport. Do not use the bridge."
        page.fill("#message", test_message)
        time.sleep(2.0)
        
        # Move to Analyze button
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 820, 680, duration=1.0)
        page.evaluate("window.highlightElement('.editor-action button.primary')")
        time.sleep(1.5)
        
        click_element(page, cur_x, cur_y)
        page.click(".editor-action button.primary")
        page.evaluate("window.clearHighlight()")
        
        # Wait for facts to appear
        page.wait_for_selector(".fact-row", timeout=25000)
        time.sleep(2.0)
        
        # Scroll smoothly to facts panel
        page.evaluate("window.scrollBy({top: 380, behavior: 'smooth'})")
        time.sleep(1.5)
        
        # Highlight facts
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 500, 420, duration=1.0) # Fact 1
        page.evaluate("window.highlightElement('.fact-row:nth-child(1)')")
        time.sleep(3.5)
        
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 500, 530, duration=1.0) # Fact 3 (time)
        page.evaluate("window.highlightElement('.fact-row:nth-child(3)')")
        time.sleep(3.5)
        
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 500, 640, duration=1.0) # Fact 4 (quantity)
        page.evaluate("window.highlightElement('.fact-row:nth-child(4)')")
        time.sleep(3.5)
        
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 500, 750, duration=1.0) # Fact 5 (negation)
        page.evaluate("window.highlightElement('.fact-row:nth-child(5)')")
        time.sleep(3.5)
        
        # Open source quote
        quotes = page.query_selector_all(".source-quote")
        if quotes:
            cur_x, cur_y = smooth_move(page, cur_x, cur_y, 350, 780, duration=0.8)
            click_element(page, cur_x, cur_y)
            quotes[0].click()
            time.sleep(2.0)
            
        page.evaluate("window.clearHighlight()")
        rem = DURATIONS["scene2_extraction"] - (time.time() - t0)
        if rem > 0:
            time.sleep(rem)
            
        # ----------------------------------------------------
        # SCENE 3: Language Selection & Translation (45.2s)
        # ----------------------------------------------------
        t0 = time.time()
        print("Scene 3 starting...")
        page.evaluate("window.setDemoTitle('3/6: Multi-Stage Translation Pipeline across Indian Languages')")
        
        # Confirm facts checkbox
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 380, 840, duration=1.0)
        page.evaluate("window.highlightElement('.confirm-facts')")
        time.sleep(1.5)
        click_element(page, cur_x, cur_y)
        page.click(".confirm-facts input[type='checkbox']")
        page.evaluate("window.clearHighlight()")
        time.sleep(1.5)
        
        # Scroll up slightly to view languages
        page.evaluate("window.scrollBy({top: -150, behavior: 'smooth'})")
        time.sleep(1.0)
        
        # Highlight language delivery panel
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 1400, 480, duration=1.2)
        page.evaluate("window.highlightElement('.language-grid')")
        time.sleep(3.0)
        
        # Select Tamil and Telugu
        # First ensure Tamil is selected, Telugu is selected
        langs = page.query_selector_all(".language-option")
        for btn in langs:
            txt = btn.inner_text()
            if "Tamil" in txt and "chosen" not in btn.get_attribute("class"):
                box = btn.bounding_box()
                cur_x, cur_y = smooth_move(page, cur_x, cur_y, box["x"] + 30, box["y"] + 20, duration=0.6)
                click_element(page, cur_x, cur_y)
                btn.click()
                time.sleep(0.5)
            elif "Telugu" in txt and "chosen" not in btn.get_attribute("class"):
                box = btn.bounding_box()
                cur_x, cur_y = smooth_move(page, cur_x, cur_y, box["x"] + 30, box["y"] + 20, duration=0.6)
                click_element(page, cur_x, cur_y)
                btn.click()
                time.sleep(0.5)
            elif "Hindi" in txt and "chosen" in btn.get_attribute("class"):
                # Uncheck Hindi to keep it focused on Tamil & Telugu
                btn.click()
                time.sleep(0.3)
                
        page.evaluate("window.clearHighlight()")
        time.sleep(1.5)
        
        # Click Translate button
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 1400, 760, duration=1.0)
        page.evaluate("window.highlightElement('.translate-button')")
        time.sleep(1.5)
        click_element(page, cur_x, cur_y)
        page.click(".translate-button")
        page.evaluate("window.clearHighlight()")
        
        # Wait for translation cards to finish loading
        page.wait_for_selector(".translation-card .native-translation", timeout=35000)
        time.sleep(2.0)
        
        # Scroll down to results section
        page.evaluate("window.scrollBy({top: 550, behavior: 'smooth'})")
        time.sleep(1.5)
        
        # Highlight Tamil card
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 500, 420, duration=1.2)
        page.evaluate("window.highlightElement('.translation-card:nth-child(1)')")
        time.sleep(4.0)
        
        # Open Inspect Every Fact details
        details = page.query_selector_all(".translation-card:nth-child(1) .audit-details")
        if details:
            cur_x, cur_y = smooth_move(page, cur_x, cur_y, 400, 520, duration=0.8)
            click_element(page, cur_x, cur_y)
            details[0].click()
            time.sleep(3.5)
            
        page.evaluate("window.clearHighlight()")
        rem = DURATIONS["scene3_translation"] - (time.time() - t0)
        if rem > 0:
            time.sleep(rem)
            
        # ----------------------------------------------------
        # SCENE 4: Bounded Repair & Gemma-4 Judge (48.1s)
        # ----------------------------------------------------
        t0 = time.time()
        print("Scene 4 starting...")
        page.evaluate("window.setDemoTitle('4/6: Bounded Repair & Independent Gemma-4 Judge')")
        
        # Move to Telugu Card (child 2)
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 1350, 420, duration=1.2)
        page.evaluate("window.highlightElement('.translation-card:nth-child(2)')")
        time.sleep(4.0)
        
        # Highlight NEEDS REVIEW pill
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 1600, 360, duration=0.8)
        page.evaluate("window.highlightElement('.translation-card:nth-child(2) .result-pill')")
        time.sleep(4.0)
        
        # Expand fact audit in Telugu card
        telugu_details = page.query_selector_all(".translation-card:nth-child(2) .audit-details")
        if telugu_details:
            cur_x, cur_y = smooth_move(page, cur_x, cur_y, 1300, 520, duration=0.8)
            click_element(page, cur_x, cur_y)
            telugu_details[0].click()
            time.sleep(4.0)
            
        # Highlight the Independent Judge badge
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 1350, 720, duration=1.0)
        page.evaluate("window.highlightElement('.translation-card:nth-child(2) .review-evidence')")
        time.sleep(5.0)
        
        # Expand Independent Judge verdicts
        judge_details = page.query_selector_all(".translation-card:nth-child(2) .review-evidence details")
        if judge_details:
            cur_x, cur_y = smooth_move(page, cur_x, cur_y, 1250, 770, duration=0.8)
            click_element(page, cur_x, cur_y)
            judge_details[0].click()
            time.sleep(5.0)
            
        page.evaluate("window.clearHighlight()")
        rem = DURATIONS["scene4_repair_judge"] - (time.time() - t0)
        if rem > 0:
            time.sleep(rem)
            
        # ----------------------------------------------------
        # SCENE 5: Research Telephone Chain & Evidence (33.8s)
        # ----------------------------------------------------
        t0 = time.time()
        print("Scene 5 starting...")
        page.evaluate("window.setDemoTitle('5/6: Research Telephone Lab & Evidence Dashboard')")
        
        # Navigate to /evidence
        page.goto(f"{BASE_URL}/evidence")
        page.wait_for_load_state("networkidle")
        page.evaluate(INJECTION_CSS_JS)
        page.evaluate("window.setDemoTitle('5/6: Research Telephone Lab & Evidence Dashboard')")
        
        cur_x, cur_y = 960, 300
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 750, 400, duration=1.2)
        page.evaluate("window.highlightElement('table')")
        time.sleep(6.0)
        
        # Navigate to /lab/
        page.goto(f"{BASE_URL}/lab/")
        page.wait_for_load_state("networkidle")
        page.evaluate(INJECTION_CSS_JS)
        page.evaluate("window.setDemoTitle('5/6: Research Telephone Chain Drift Simulator')")
        
        cur_x, cur_y = 960, 300
        cur_x, cur_y = smooth_move(page, cur_x, cur_y, 600, 350, duration=1.2)
        time.sleep(6.0)
        
        page.evaluate("window.clearHighlight()")
        rem = DURATIONS["scene5_research_evidence"] - (time.time() - t0)
        if rem > 0:
            time.sleep(rem)
            
        # ----------------------------------------------------
        # SCENE 6: Conclusion & Architecture (27.1s)
        # ----------------------------------------------------
        t0 = time.time()
        print("Scene 6 starting...")
        page.goto(BASE_URL)
        page.wait_for_load_state("networkidle")
        page.evaluate(INJECTION_CSS_JS)
        page.evaluate("window.setDemoTitle('6/6: Tech Stack & Architecture | Presented by Viksit Garg')")
        
        # Inject Outro Card
        OUTRO_JS = """
        (() => {
          const outro = document.createElement('div');
          outro.id = 'demo-outro';
          outro.innerHTML = `
            <div style="background: rgba(15, 23, 42, 0.95); backdrop-filter: blur(20px); border: 2px solid rgba(13, 148, 136, 0.6); border-radius: 24px; padding: 48px; max-width: 880px; box-shadow: 0 30px 80px rgba(0,0,0,0.8); text-align: center; color: white; font-family: system-ui, sans-serif;">
              <div style="width: 72px; height: 72px; border-radius: 20px; background: linear-gradient(135deg, #0d9488, #0f766e); display: flex; align-items: center; justify-content: center; font-size: 38px; color: white; margin: 0 auto 20px auto; box-shadow: 0 10px 25px rgba(13, 148, 136, 0.5);">↝</div>
              <div style="font-size: 14px; font-weight: 800; text-transform: uppercase; letter-spacing: 2px; color: #5eead4; margin-bottom: 8px;">Culture Coded Track · Sarvam AI Hackathon</div>
              <h1 style="font-size: 38px; font-weight: 800; margin: 0 0 12px 0; letter-spacing: -0.5px;">Telephone Lab</h1>
              <p style="font-size: 18px; color: #94a3b8; margin: 0 0 28px 0;">Presented by <strong style="color: #ffffff;">Viksit Garg</strong></p>
              
              <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 28px; text-align: left;">
                <div style="background: rgba(255,255,255,0.05); padding: 16px 20px; border-radius: 14px; border: 1px solid rgba(255,255,255,0.1);">
                  <div style="color: #5eead4; font-weight: 700; font-size: 15px; margin-bottom: 4px;">Grounded Verification</div>
                  <div style="font-size: 13px; color: #cbd5e1;">Exact source quotes & deterministic dates/times checks</div>
                </div>
                <div style="background: rgba(255,255,255,0.05); padding: 16px 20px; border-radius: 14px; border: 1px solid rgba(255,255,255,0.1);">
                  <div style="color: #a5b4fc; font-weight: 700; font-size: 15px; margin-bottom: 4px;">Sarvam + Gemma-4</div>
                  <div style="font-size: 13px; color: #cbd5e1;">Sarvam-105B translation with independent Gemma-4 rubric judge</div>
                </div>
                <div style="background: rgba(255,255,255,0.05); padding: 16px 20px; border-radius: 14px; border: 1px solid rgba(255,255,255,0.1);">
                  <div style="color: #fcd34d; font-weight: 700; font-size: 15px; margin-bottom: 4px;">100 Tests & D1 Quotas</div>
                  <div style="font-size: 13px; color: #cbd5e1;">Full Cloudflare Workers + D1 atomic quota protection</div>
                </div>
              </div>
              
              <div style="font-size: 15px; color: #5eead4; font-weight: 600;">Change the language. Keep the meaning. Thank you!</div>
            </div>
          `;
          outro.style.cssText = `
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(0,0,0,0.65);
            z-index: 2147483647;
            animation: fadeIn 0.5s ease-out;
          `;
          document.body.appendChild(outro);
        })();
        """
        page.evaluate(OUTRO_JS)
        
        rem = DURATIONS["scene6_conclusion"] - (time.time() - t0)
        if rem > 0:
            time.sleep(rem)
            
        print("Closing browser and finishing video capture...")
        context.close()
        browser.close()
        print("Playwright recording completed!")

if __name__ == "__main__":
    run()
