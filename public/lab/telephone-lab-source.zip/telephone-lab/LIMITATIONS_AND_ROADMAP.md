# Telephone Lab — Internal Limitations, Validation Notes & Future Roadmap

> **CONFIDENTIAL / INTERNAL USE ONLY**  
> *This document contains evaluation constraints, experimental notes, and future technical roadmap items. It is excluded from public source distributions and repositories via `.gitignore`.*

---

## 1. Technical Boundaries & Validation Notes

### Automated Preservation Checks
- Automated checks (even with deterministic normalization for numbers, times, and dates) can still miss subtle cultural or dialect nuances.
- Normalization currently supports English and 9 Indian language numeric scripts (Devanagari, Tamil, Telugu, Kannada, Malayalam, Gujarati, Punjabi, Bengali), but complex compound numbers, conversational word numbers, and fuzzy place semantics benefit from human review.
- While deterministic guards override model hallucinations for quantities and dates, actions and conditions rely on LLM semantic verification.

### Model Integration & Single-Family Bias
- Studio translation and back-translation use Sarvam-105B with separate task prompts.
- To mitigate single-family circular bias, an independent-model rubric judge using **Gemma-4** (via Sarvam V2) is implemented to evaluate translations independently. Disagreements and rubric reasons are surfaced transparently.

### Human / Native Speaker Ground Truth
- The 76 candidate hard-case test fixtures in `tests/gold/` are engineered calibration controls; they serve as programmatic regression fixtures rather than certified human-evaluated gold sets.
- Review infrastructure (tamper-evident review packs, offline review form `/reviewer.html`, D1 ingestion API) is in place, awaiting scaled multi-reviewer community submissions.

---

## 2. Research Chain drift experiment (`/lab/`)
- In the multi-hop research chain (Hindi $\rightarrow$ Tamil $\rightarrow$ Hindi and held-out chains), hop retellings explore cumulative drift in safety-critical facts.
- 5 of 12 experimental settings completed full N=10 real-provider evaluations before rate ceilings were hit. Remaining cells are cached and resumable under `results/real/`.
- Per-language coverage in `results/real/coverage/matrix.json` currently records 1 full verified translation and round-trip across all 10 languages, with target expansion to $\ge 3$ scenarios planned.

---

## 3. Future Roadmap

1. **Speech Hops (Audio-to-Audio / TTS-STT)**:
   - Voice telephone chains utilizing Sarvam's speech APIs once text-based fact survival metrics meet target thresholds.
2. **Community Review Portal**:
   - Web-based volunteer native-speaker evaluation interface with reputation scoring.
3. **Dialect Adaptation**:
   - Specialized prompts and evaluation for non-standard regional dialects across Northern and Southern linguistic zones.
4. **Offline Mobile Edge Deployment**:
   - Running lightweight quantifier and date guards directly on edge devices (Android/iOS) for zero-latency offline emergency checks.
