# Limitations slide / pitch notes

- **Speakers are simulated.** A chat model retelling a message is not evidence of how communities pass on warnings.
- **Current bundled results are mock.** Artificial mutations and label-sensitive synthetic noise are programmed. The numerical gains are not language findings.
- **No dialect accuracy claim.** Bhojpuri is not included; no native-speaker quality review has happened.
- **Grading can be biased.** Independent prompts reduce direct leakage, but the default judge shares a model with the reteller. Normalization and extraction can hallucinate.
- **Limited schema.** Six fields do not capture every invented claim; conflicting multiple values need richer evidence representation.
- **Small samples.** Ten trials per setting test the pipeline; they do not establish statistical significance or deployment readiness.
- **Length is measured, naturalness is not.** Label-heavy rewrites need real-user comprehension checks.
- **No live claims.** Provider connectivity and quality await a key. Optional voice pipeline omitted.
- **Never an alert service.** All scenarios and locations are fictional. No operational decision should rely on these scores.

Next real study: independent native-language extraction, native-speaker chains, preregistered unseen scenarios and orders, comprehension grading, confidence intervals, and careful consent.
