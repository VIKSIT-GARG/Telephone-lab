# Phase 2 report

Summary: The existing studio has been extended with explicit deterministic safety guards, an independent-family judge, evidence and review workflows, durable quotas and patched dependencies. Real provider tests and a partial research study were run; no human validation or complete three-scenario study is claimed.

## Verified (with evidence)

- 24 Python + 76 Node tests passed (100 total), with all original coverage retained. TypeScript and Worker builds passed. CI configuration is included; a remote CI run is not claimed.
- 76 assistant-authored hard-case fixtures with explicit unreviewed authorship; 0 human-reviewed. Engineering exact verdict agreement: 67/76 cases. Mutation-detection flags: 66/66 positive cases, with 3 false alarms among 76 controls. This is not headline translation accuracy.
- Independent programmatic injection suite: 40/40 mutations flagged, 40/40 unchanged controls unflagged; 20 unsupported injection forms skipped and recorded. Full per-type before/after counts are in CHECKER_EVAL.md.
- Real one-case translation + round trip for every offered target language (10/10); all remain limited testing / automated-checks-only.
- Gemma4 independent-family sample completed through verified Sarvam V2: 2/3 critical-fact agreement, one translation. Gemma is served by the same provider and is not a native-speaker validator.
- Native review packs, offline form, exact source/translation/fact-set hashes, import, anonymous retention/deletion and calibration logic implemented. Browser QA loaded a real sample pack without creating any human verdict.
- Hosted D1 quotas and storage verified via HTTP. HTTP status/input-size/origin/invalid-review/validation/live-analysis/live-translation checks passed; security headers and default absence of raw provider content were checked. This verifies operations, not translation accuracy. Later atomic-extraction warnings/retry and expanded added-claim bounds have unit/type/build verification; final live re-testing is blocked by the network restriction below.
- Production dependency audit: zero known advisories after patches (point-in-time production scope). See DEPENDENCY_AUDIT.md; no security certification implied.

## Blocked / unverified

The execution environment blocked direct network access to `api.sarvam.ai`. No bypass was attempted. 5 of 12 research settings completed N=10 before that restriction; remaining cells stay not-run or partial. Raw responses, failed outputs and resumable caches are retained. See EVALUATION.md for per-setting CFS, danger rate, confidence intervals, mutation counts and length ratios.

No human/native-speaker reviews exist. The candidate gold set is not human-reviewed; its reported engineering scores are not independent calibration. All ten languages have only one completed coverage case, below the declared minimum of three. Translation quality, complex conditions, fuzzy names and cross-language time/number interpretations remain unverified.

## Checker: recall and precision before vs after

See CHECKER_EVAL.md for every mutation type with denominators. The comparison isolates deterministic guards under a simulated passing judge; it is not an old/new end-to-end LLM benchmark. Negation, condition and certainty paraphrases each retain a false alarm. Places frequently require an explicit unverified flag. Unknown/ambiguous evidence earns no preservation credit.

## Real evaluation

Protocol frozen before calls: three rich fictional scenarios, training A (Hindi → Tamil → Hindi), held-out B (Tamil → Bengali → Marathi → Hindi), N=10 per setting, two training candidates with two selection trials each, character cap 1.6×. Selection was frozen before held-out work. The optimizer retained the original in all three scenarios; observed differences are repeated-run noise, not rewrite efficacy.

Initial pilot: 24-call / INR 5 cap. Extended run: 1,400-call / INR 25 ceiling and pacing at most 40 fresh requests/minute. Actual ledger is included in EVALUATION.md. Token charges are estimates from documented rates and reported usage, not an invoice. Provider failures/incomplete chains are excluded from scored-chain means and retained separately; this conditional denominator can bias CFS. CFS uses whole-trial bootstrap intervals; danger uses Wilson intervals. N<2 has no CI. No fabricated values fill missing settings.

## Judge and human validation

Per-result statuses distinguish automated-only, judge-checked and imported self-declared human evidence. Independent disagreements and failures remain visible. Native-speaker calibration: unavailable (0 reviewers, 0 cases). The review infrastructure is ready; genuine reviewers are still required.

## Language coverage

Hindi, Tamil, Bengali, Marathi, Telugu, Kannada, Malayalam, Gujarati, Punjabi and English: one real sample and round trip each; all limited testing. Script/digit normalization has regression coverage, but native-script quality has not been reviewed by speakers. See LANGUAGE_COVERAGE.md.

## Hardening

Added D1 atomic request/call/spend quotas, fail-closed storage handling, bounded retries/timeouts, streaming input limits, same-origin checks, security headers, metadata-only server logs, opt-in debug reports, anonymous-review retention/deletion and production dependency patches. SQLite operational tests verify concurrent reservations and persistence. Direct executor HTTP to managed preview timed out; browser preview and hosted HTTP were separately checked. Broader load testing, independent security review, scheduled retention pruning and billing reconciliation remain.

## Stretch / speech

None claimed complete. Optional speech and G stretch features remain gated because A–D validation is incomplete. The engineering fixtures are provided as candidate data, not a validated public Hindi benchmark.

## Next steps

Restore legitimate provider access and resume the cached remaining settings; obtain native-speaker gold/review judgments; calibrate false positives and independent-judge agreement; improve atomic extraction and candidate generation before claiming reliable preservation or optimization efficacy.

## Progress log

| Step | Status | Evidence / next |
|---|---|---|
| 1. Inspect and re-verify docs | Complete | VERIFIED.md |
| 2. A: checker / gold / mutations | Implemented; human gold review blocked | 0/76 human-reviewed; engineering counts only |
| 3. C: real evaluation | Partial / network blocked | 5 of 12 settings at N=10 |
| 4. B: judge / review workflows | Implemented; human calibration blocked | Real Gemma sample; no human reviews |
| 5. D: language matrix | Limited testing | 1 case/target; minimum 3 not met |
| 6. F: hardening | Implemented and operationally checked | Wider production validation remains |
| 7. E: speech | Gated / not implemented | Prior evidence incomplete |
| 8. G: stretch | Gated / not implemented | Prior evidence incomplete |
